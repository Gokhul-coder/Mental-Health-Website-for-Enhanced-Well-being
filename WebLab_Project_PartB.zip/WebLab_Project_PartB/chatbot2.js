const chatDisplay = document.getElementById('chat-display');
const userInputElement = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

// Bot responses based on selected option
function botResponse(option) {
    switch (option) {
        case 'option1':
            return "You selected Option 1.";
        case 'option2':
            return "You selected Option 2.";
        case 'option3':
            return "You selected Option 3.";
        default:
            return "I'm sorry, I didn't understand that.";
    }
}

sendButton.addEventListener('click', function() {
    const userMessage = userInputElement.value.trim();
    if (userMessage !== '') {
        const userMessageDiv = document.createElement('div');
        userMessageDiv.classList.add('user-message');
        userMessageDiv.textContent = 'You: ' + userMessage;
        chatDisplay.appendChild(userMessageDiv);
        
        // Simulating a slight delay before bot's response
        setTimeout(function() {
            const optionSelected = userMessage.toLowerCase();
            const botMessageDiv = document.createElement('div');
            botMessageDiv.classList.add('bot-message');
            botMessageDiv.textContent = 'Bot: ' + botResponse(optionSelected);
            chatDisplay.appendChild(botMessageDiv);
            
            // Scroll to the bottom of the chat display
            chatDisplay.scrollTop = chatDisplay.scrollHeight;
            
            userInputElement.value = '';
        }, 500);
    }
});
